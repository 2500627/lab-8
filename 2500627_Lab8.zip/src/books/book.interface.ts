// Name: YOUR NAME HERE | Reg. No: 2500627
// Shape of a book stored in memory.
export interface Book {
  id: number;
  title: string;
  author: string;
  year: number;
  available: boolean;
}

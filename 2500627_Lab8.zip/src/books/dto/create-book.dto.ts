// Name: YOUR NAME HERE | Reg. No: 2500627
// DTO used for POST /books. Validation rules are checked by ValidationPipe.
import { IsBoolean, IsInt, IsNotEmpty, IsOptional, IsString, Max, Min } from 'class-validator';

export class CreateBookDto {
  @IsString()
  @IsNotEmpty()
  title: string;

  @IsString()
  @IsNotEmpty()
  author: string;

  @IsInt()
  @Min(1900)
  @Max(2026)
  year: number;

  // Optional on create; defaults to true in the service.
  @IsOptional()
  @IsBoolean()
  available?: boolean;
}

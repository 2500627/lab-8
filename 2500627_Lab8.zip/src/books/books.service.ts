// Name: YOUR NAME HERE | Reg. No: 2500627
// BooksService: business logic with in-memory storage.
// Receives LoggerService and LIBRARY_CONFIG by dependency injection.
import { BadRequestException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { LoggerService } from '../logger/logger.service';
import { LIBRARY_CONFIG } from './books.constants';
import { Book } from './book.interface';
import { CreateBookDto } from './dto/create-book.dto';
import { UpdateBookDto } from './dto/update-book.dto';

@Injectable()
export class BooksService {
  private books: Book[] = [
    { id: 1, title: 'Clean Code', author: 'Robert C. Martin', year: 2008, available: true },
    { id: 2, title: 'The Pragmatic Programmer', author: 'Andrew Hunt', year: 1999, available: true },
  ];
  private nextId = 3;

  constructor(
    private readonly logger: LoggerService,
    @Inject(LIBRARY_CONFIG) private readonly config: { maxBooks: number },
  ) {}

  // GET /books  (optional filter ?available=true|false)
  findAll(available?: boolean): Book[] {
    this.logger.log(`findAll called (available filter: ${available})`);
    if (available === undefined) return this.books;
    return this.books.filter((b) => b.available === available);
  }

  // GET /books/search?title=...  (bonus)
  search(title: string): Book[] {
    this.logger.log(`search called with title "${title}"`);
    const t = (title ?? '').toLowerCase();
    return this.books.filter((b) => b.title.toLowerCase().includes(t));
  }

  // GET /books/:id
  findOne(id: number): Book {
    this.logger.log(`findOne called for id ${id}`);
    const book = this.books.find((b) => b.id === id);
    if (!book) throw new NotFoundException(`Book with id ${id} not found`);
    return book;
  }

  // POST /books
  create(dto: CreateBookDto): Book {
    this.logger.log('create called');
    if (this.books.length >= this.config.maxBooks) {
      throw new BadRequestException(`Library is full (max ${this.config.maxBooks} books)`);
    }
    const book: Book = {
      id: this.nextId++,
      title: dto.title,
      author: dto.author,
      year: dto.year,
      available: dto.available ?? true,
    };
    this.books.push(book);
    return book;
  }

  // PUT /books/:id
  update(id: number, dto: UpdateBookDto): Book {
    this.logger.log(`update called for id ${id}`);
    const book = this.findOne(id);
    Object.assign(book, dto);
    return book;
  }

  // DELETE /books/:id
  remove(id: number): { message: string } {
    this.logger.log(`remove called for id ${id}`);
    const book = this.findOne(id);
    this.books = this.books.filter((b) => b.id !== book.id);
    return { message: `Book ${id} deleted` };
  }

  // PUT /books/:id/borrow  (bonus)
  borrow(id: number): Book {
    this.logger.log(`borrow called for id ${id}`);
    const book = this.findOne(id);
    if (!book.available) throw new BadRequestException('Book is already borrowed');
    book.available = false;
    return book;
  }
}

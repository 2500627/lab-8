// Name: YOUR NAME HERE | Reg. No: 2500627
// Injection token + config value for the library.
export const LIBRARY_CONFIG = 'LIBRARY_CONFIG';

export const libraryConfigValue = { maxBooks: 10 };
